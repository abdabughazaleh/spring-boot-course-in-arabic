public class TestClass {

    @MyAnnotation(log = "...")
    String name;

    @MyAnnotation(log = "log .........")
    public void testMethod() {

    }

}
