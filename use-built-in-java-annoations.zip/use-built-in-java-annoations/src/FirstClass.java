import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

public class FirstClass extends SecondClass {

    @Deprecated
    private String firstName;

    @Override
    public void testMethod() {
        System.out.println("FirstClass executed testMethod .....");
    }

    @Deprecated
        // @ Ann Name ...
    void anotherSomethingToDo() {

    }

}
