public class SecondClass {


    public void testMethod(){
        System.out.println("FirstClass executed testMethod .....");
    }
}
